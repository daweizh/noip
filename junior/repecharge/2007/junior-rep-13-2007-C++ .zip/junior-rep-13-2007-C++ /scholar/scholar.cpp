#include <iostream>
using namespace std;

int main(){
	int id[305],lng[305],mat[305],eng[305],tot[305],n;
	id[0] = 0,lng[0] = 0,	mat[0] = 0,	eng[0] = 0,	tot[0] = 0;
	
	cin >> n;
	
	for(int i=1;i<=n;i++){
		id[i] = i;
		cin >> lng[i] >> mat[i] >> eng[i];
		tot[i] = lng[i] + mat[i] + eng[i];
	}
	
	for(int i=0;i<n;i++){
		for(int j=i+1;j<=n;j++){
			if(tot[j]>tot[i]){
				int temp = tot[i];
				tot[i]= tot[j];
				tot[j] = temp;

				temp = id[i];
				id[i]= id[j];
				id[j] = temp;

				temp = lng[i];
				lng[i]= lng[j];
				lng[j] = temp;

				temp = mat[i];
				mat[i]= mat[j];
				mat[j] = temp;

				temp = eng[i];
				eng[i]= eng[j];
				eng[j] = temp;
			}
		}
	}

	for(int i=0;i<n;i++){
		int j= i+1;
		for(;j<=n;j++){
			if(tot[i]!=tot[j]){
				break;
			}
		}
		if(j-i>1){
			for(int a=i;a<j-1;a++)
				for(int b=a+1;b<=j-1;b++){
					if(lng[b]>lng[a]){
						int temp = tot[a];
						tot[a]= tot[b];
						tot[b] = temp;
		
						temp = id[a];
						id[a]= id[b];
						id[b] = temp;
		
						temp = lng[a];
						lng[a]= lng[b];
						lng[b] = temp;
		
						temp = mat[a];
						mat[a]= mat[b];
						mat[b] = temp;
		
						temp = eng[a];
						eng[a]= eng[b];
						eng[b] = temp;
					}
				}
		
		}
	}
	
	for(int i=0;i<5;i++){
		cout << id[i] << " " << tot[i] << endl;
	}
	
	return 0;
}
