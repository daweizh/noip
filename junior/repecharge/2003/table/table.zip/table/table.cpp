#include <bits/stdc++.h>
using namespace std;

int main(){
	char c[100000],t;
	long i = 0;
	
	t=cin.get();
	while(t!='E'){
		if (t!='\n' && t!='\r')
			c[i++] = t;
		t = cin.get();
	}
	
	if(i==0){
		cout << "0:0" << endl;
		cout << endl;
		cout << "0:0" << endl;
	}

	int w=0,l=0;
	for (int j=0;j<i;j++){
		if(c[j]=='W') w = w + 1;
		if(c[j]=='L') l = l + 1;
		
		if((w>=11 && w-l>=2) || (l>=11 && l-w>=2)){
			cout << w << ":" << l << endl;
			w = 0;
			l = 0;
		}
	}
	if (i>0)
		cout << w << ":" << l << endl;
	cout << endl;
	
	w=0,l=0;
	for (int j=0;j<i;j++){
		if(c[j]=='W') w = w + 1;
		if(c[j]=='L') l = l + 1;
		
		if((w>=21 && w-l>=2) || (l>=21 && l-w>=2)){
			cout << w << ":" << l << endl;
			w = 0;
			l = 0;
		}
	}
	if (i>0)
		cout << w << ":" << l << endl;
	
		
	return 0;
}
