#include <iostream>
using namespace std;

int main(){
	int h[10],l,c=0;
	for(int i=0;i<10;i++)
		cin >> h[i];
	cin >> l;
	for(int i=0;i<10;i++){
		if((l+30)>=h[i]){
			c= c + 1;
		}
	}
	cout << c << endl;

	return 0;
}
