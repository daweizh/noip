#include <bits/stdc++.h>
using namespace std;

int main(){
	int week[8],a,b,max = 0,day=0;
	
	for(int i=1;i<8;i++){
		cin >> a >> b ;
		week[i] = a + b;
	}

	for(int i=1;i<8;i++){
		if(week[i]>8 && week[i]>max){
			max = week[i];
			day = i;
		}
	}
	
	cout << day << endl;
	
	return 0;
}
