#include <iostream>
using namespace std;

int main(){
	int r[1005],n,a,m[105];
	
	for(int i=0;i<1005;i++)
		r[i] = 0;
		
	cin >> n;

	for(int i=0;i<n;i++){
		cin >> a;
		r[a] = a;
	}	
	n = 0;
	
	for(int i=0;i< 1005;i++)
		if(r[i]>0){
			m[n] = r[i];
			n = n + 1;
		}
	
	for(int i=0;i<n-1;i++)
		for(int j=i+1;j<n;j++)
			if(m[j]<m[i]){
				int t = m[i];
				m[i] = m[j];
				m[j] = t;
			}
	cout << n << endl;
	for(int i=0;i<n;i++)
		cout << m[i] << " ";
	cout << endl;
	
	return 0;
}
